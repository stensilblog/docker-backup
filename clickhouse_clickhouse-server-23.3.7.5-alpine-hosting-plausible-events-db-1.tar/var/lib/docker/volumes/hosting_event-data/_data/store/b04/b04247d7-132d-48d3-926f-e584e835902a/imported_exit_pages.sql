ATTACH TABLE _ UUID '0141ab8b-defe-4f3b-90af-2fcb4ae5bf30'
(
    `site_id` UInt64,
    `date` Date,
    `exit_page` String,
    `visitors` UInt64,
    `exits` UInt64
)
ENGINE = MergeTree
ORDER BY (site_id, date, exit_page)
SETTINGS index_granularity = 8192
