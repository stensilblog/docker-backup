ATTACH TABLE _ UUID '919011c1-b762-4fef-965c-d08d262d2c3f'
(
    `version` Int64,
    `inserted_at` DateTime
)
ENGINE = TinyLog
