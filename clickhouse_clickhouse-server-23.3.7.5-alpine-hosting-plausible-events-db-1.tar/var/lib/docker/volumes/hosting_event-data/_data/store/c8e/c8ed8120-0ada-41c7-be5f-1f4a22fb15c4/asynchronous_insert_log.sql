ATTACH TABLE _ UUID '4ed2ffb1-1a45-4425-82e5-12a620ce2da8'
(
    `event_date` Date,
    `event_time` DateTime,
    `event_time_microseconds` DateTime64(6),
    `query` String,
    `database` LowCardinality(String),
    `table` LowCardinality(String),
    `format` LowCardinality(String),
    `query_id` String,
    `bytes` UInt64,
    `exception` String,
    `status` Enum8('Ok' = 0, 'ParsingError' = 1, 'FlushError' = 2),
    `flush_time` DateTime,
    `flush_time_microseconds` DateTime64(6),
    `flush_query_id` String
)
ENGINE = MergeTree
PARTITION BY event_date
ORDER BY (database, table, event_date, event_time)
TTL event_date + toIntervalDay(3)
SETTINGS index_granularity = 8192
